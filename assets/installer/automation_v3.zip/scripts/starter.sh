#!/bin/sh

 if [ $(id -u) != 0 ]; then
     	echo "Root permission is required"
	exit 1
else
	echo -n "The program will be installed on pi account, please wait.."

	version=`bash javachecker.sh`
	
	if (( ${version} >= 8 )); then
		authservice=`sudo systemctl show -p ActiveState --value automation.service`
			if [[ $authservice == "failed" ]]; then
			     echo "Now installing the program"
			     sudo dpkg -i ../installer/automation.deb
   			     clear
			     echo "Installation complete"
			fi

			if [[ $authservice == "inactive" ]]; then
 			     echo "Now installing the program"
			     sudo dpkg -i ../installer/automation.deb
			     clear
			     echo "Installation complete"
			fi
	else 
	   echo "Java not found or version incompatible"
	fi
fi
